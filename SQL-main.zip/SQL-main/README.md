# SQL
Welcome to my SQL projects!

**New Wheels Project**

A SQL and Excel project that aims to analyze customer ratings, purchasing history, revenue, shipment times, 
and customer feedback data to evaluate a vehicle company's performance and identify its strengths and
weaknesses, with the goal of providing recommendations for improvement. 

Findings include customer preference for Chevrolet vehicles and a positive correlation with decreasing customer
ratings and orders from quarter 1 to quarter 4. Shipment delays and a quarterly increase in the number of days
to ship are possible causes. Increasing Chevrolet vehicles may attract further customers.
